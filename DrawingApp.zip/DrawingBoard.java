package myPackage;

import java.util.Scanner;

public class DrawingBoard 
{
	public static void main(String arg[]) throws Exception
	{
		menu();
	}
	
	public static void menu() throws Exception
	{
		Window window;
		System.out.println("Enter the window file name (or NEW): ");
		Scanner scanner = new Scanner(System.in);
		String input = scanner.nextLine();
		if (input.equals("NEW"))
		{
			System.out.println("Enter the number of rows, number of columns and character (seperated by space): ");
			input = scanner.nextLine();
			String[] arr = input.split(" ");
			window = new Window(Integer.parseInt(arr[0]),Integer.parseInt(arr[1]),arr[2].charAt(0));
		}
		else
			window = Window.readSpecFromFile(input);
		
		if (window != null)
			window.display();
		else
			System.out.println("File was empty!");
		boolean quit = false;
		String arr[];
		while (quit == false)
		{
			System.out.println("Add Erase Select Write Quit");
			System.out.println("Up Down Left Right + -");
			input = scanner.nextLine();
			if (input.equals("a"))
			{
				System.out.println("line rowBase colBase length rowIncrement colIncrement character");
				input = scanner.nextLine();
				arr = input.split(" ");
				try {
					if (arr[0].equals("line"))
					{
						Line line = new Line(Integer.parseInt(arr[1]),Integer.parseInt(arr[2]),
								Integer.parseInt(arr[3]),Integer.parseInt(arr[4]),
								Integer.parseInt(arr[5]), arr[6].charAt(0));
						window.addShape(line);
					}
					else if(arr[0].equals("rectangle"))
					{
						Rectangle rectangle = new Rectangle(Integer.parseInt(arr[1]),Integer.parseInt(arr[2]),
								Integer.parseInt(arr[3]),Integer.parseInt(arr[4]),arr[5].charAt(0));
						window.addShape(rectangle);
					}
				}
				catch(Exception e)
				{
					System.out.println("Format of input is not recognized");
				}
			}
			else if(input.equals("e"))
			{
				window.displayInfo();
				input = scanner.nextLine();
				try {
					window.removeShape(Integer.parseInt(input));
				}
				catch(Exception e)
				{
					System.out.println("Format of input is not recognized");
				}
			}
			
			else if(input.equals("s"))
			{
				try {
					window.displayInfo();
					input = scanner.nextLine();
					int ID = Integer.parseInt(input);
					window.display();
					System.out.println("Add Erase Select Write Quit");
					System.out.println("Up Down Left Right + -");
					input = scanner.nextLine();
					if (input.equals("+"))
						window.increaseSize(ID);
					else if(input.equals("-"))
						window.decreaseSize(ID);
					else if (input.equals("l"))
						window.moveShape(ID,"l");
					else if (input.equals("r"))
						window.moveShape(ID,"r");
					else if (input.equals("u"))
						window.moveShape(ID,"u");
					else if (input.equals("d"))
						window.moveShape(ID,"d");
				}
				catch (Exception e)
				{
					System.out.println("Format of input is not recognized");
				}
			}
			
			else if(input.equals("w"))
			{
				System.out.print("File name: ");
				input = scanner.nextLine();
				try {
					window.writeToFile(input);
				}
				catch(Exception e)
				{
					System.out.println("Format of input is not recognized");
				}
			}
			
			else if(input.equals("q"))
			{
				System.out.println("Thank you!");
				quit = true;
			}
			if (quit == false)
			{
				window.refreshImage();
				window.display();
				window.displayInfo();
			}
		}
		scanner.close();
	}
}
