package myPackage;

import java.util.Scanner;

public class T4Main 
{
	public static void main(String arg[]) throws Exception
	{
		Scanner scanner = new Scanner(System.in);
		String input;
		System.out.print("Enter file name: ");
		input = scanner.nextLine();
		Window window = Window.readSpecFromFile(input);
		window.display();
		scanner.close();
	}
}
