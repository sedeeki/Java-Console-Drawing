package myPackage;

import java.io.IOException;

public class T2Main 
{
	public static void main(String arg[]) throws IOException 
	{
		Window w = new Window(20, 30, '*');
		Line ground = new Line(19, 1, 29, 0, 1,'#');
		w.addShape(ground);
		Line post = new Line(12, 5, 6, 1, 0, '#');
		w.addShape(post);
		Circle light = new Circle(10, 5, 2, '+'); 
		w.addShape(light);
		Rectangle house = new Rectangle(8, 16, 11, 10, '=');
		w.addShape(house);
		Rectangle door = new Rectangle(11, 19, 8, 4, '=');
		w.addShape(door);
		Triangle roof = new Triangle(2, 21, 6, 1, 0, '*'); 
		w.addShape(roof);
		Text msg = new Text(2,10, "FOR SALE", 1, 0);
		w.addShape(msg);
		w.display();
		w.writeToFile("Complete.txt");
	}
}
