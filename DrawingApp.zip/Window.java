package myPackage;

import java.io.BufferedWriter;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class Window 
{
	private int height;
	private int width; 
	private char symbol;
	private char[][] arr;
	private ArrayList <Shape> shapes;
	
	Window()
	{
		height = 0;
		width = 0;
		symbol = '0';
	}
	
	Window(int h, int w, char s)
	{
		height = h + 2;
		width = w + 2;
		symbol = s;
		arr = new char[height][width];
		for (int i = 0; i < height; i++)
		{
			for (int j = 0; j < width; j++)
			{
				if ((i == 0 || i == height - 1) || (j == 0 || j == width - 1))
					arr[i][j] = symbol;
				else
					arr[i][j] = ' ';
			}
		}
		shapes = new ArrayList <Shape> ();
	}
	
	public void addShape(Shape shape)
	{
		shapes.add(shape);
	}
	
	public void removeShape(int ID)
	{
		shapes.remove(ID);
	}
	
	public char[][] getArr()
	{
		return arr;
	}
	
	public void display()
	{
		for (int i = 0; i < shapes.size(); i++)
			shapes.get(i).draw(this); 	
		for (int i = 0; i < height; i++)
		{
			for (int j = 0; j < width; j++)
				System.out.print(arr[i][j] + " ");
			System.out.println("");
		}
	}
	
	public void increaseSize(int ID)
	{
		shapes.get(ID).increaseSize();
		shapes.get(ID).draw(this);
	}
	
	public void decreaseSize(int ID)
	{
		shapes.get(ID).decreaseSize();
	}
	
	public void moveShape(int ID, String s)
	{
		shapes.get(ID).move(s);
	}
	
	public void displayInfo()
	{
		for (int i = 0; i < shapes.size(); i++)
		{
			System.out.print(i + ": ");
			shapes.get(i).displayInfo();
		}
	}
	
	public String toString()
	{
		String info = Integer.toString(this.height - 2) + " " + Integer.toString(this.width - 2);
		info = info + "\n" + this.symbol;
		return info;
	}
	
	public void writeToFile(String fileName) throws IOException
	{
		BufferedWriter bw = new BufferedWriter(new FileWriter( new File (fileName)));
		bw.write(this.toString() + "\n.\n");
		for (int i = 0; i < shapes.size(); i++)
			bw.write(shapes.get(i).toString() + "\n.\n");
		bw.close();
	}
	
	public static Window readSpecFromFile(String fileName) throws Exception
	{
		BufferedReader br = new BufferedReader(new FileReader(new File(fileName)));
		String line;
		Window window;
		window = null;
		String arr[];
		while ((line = br.readLine()) != null)
		{
			arr = line.split(" ");
			window = new Window(Integer.parseInt(arr[0]),Integer.parseInt(arr[1]),br.readLine().charAt(0));
			while ((line = br.readLine()) != null)
			{
				if (line.equals("."))
				{
					line = br.readLine();
					if (line != null)
					{
						if (line.contains("line"))
						{
							System.out.println(line);
							Line line1;
							line = br.readLine();
							arr = line.split(" ");
							line = br.readLine();
							line1 = new Line(Integer.parseInt(arr[0]),Integer.parseInt(arr[1]),Integer.parseInt(arr[2]),
									Integer.parseInt(arr[3]),Integer.parseInt(arr[4]),line.charAt(0));
							window.addShape(line1);
						}
						else if (line.contains("rectangle"))
						{
							Rectangle rectangle;
							line = br.readLine();
							arr = line.split(" ");
							line = br.readLine();
							rectangle = new Rectangle(Integer.parseInt(arr[0]),Integer.parseInt(arr[1]),
									Integer.parseInt(arr[2]), Integer.parseInt(arr[3]),line.charAt(0));
							window.addShape(rectangle);
						}
						
						else if (line.contains("triangle"))
						{
							Triangle triangle;
							line = br.readLine();
							arr = line.split(" ");
							line = br.readLine();
							triangle = new Triangle(Integer.parseInt(arr[0]),Integer.parseInt(arr[1]),
									Integer.parseInt(arr[2]),Integer.parseInt(arr[3]),Integer.parseInt(arr[4]),
									line.charAt(0));
							window.addShape(triangle);
						}
						
						else if (line.contains("circle"))
						{
							Circle circle;
							line = br.readLine();
							arr = line.split(" ");
							line = br.readLine();
							circle = new Circle(Integer.parseInt(arr[0]),Integer.parseInt(arr[1]),
									Integer.parseInt(arr[2]),line.charAt(0));
							window.addShape(circle);
						}
						else if (line.contains("text"))
						{
							Text text;
							String arr2[];
							line = br.readLine();
							arr = line.split(" ");
							line = br.readLine();
							String s = line;
							line = br.readLine();
							arr2 = line.split(" ");
							text = new Text(Integer.parseInt(arr[0]),Integer.parseInt(arr[1]),s,
									Integer.parseInt(arr2[0]),Integer.parseInt(arr2[1]));
							window.addShape(text);
						}
					}
				}
			}
		}
		br.close();
		return window;
	}
	
	public void addGrid()
	{
		int count = 1;
		for (int i = 1; i < width - 1; i++)
		{
			arr[0][i] = Character.forDigit(count%10, 10);
			arr[height-1][i] = Character.forDigit(count%10, 10);
			count++;
		}
		count = 1;
		for (int i = 1; i < height - 1; i++)
		{
			arr[i][0] = Character.forDigit(count%10, 10);
			arr[i][width-1] = Character.forDigit(count%10, 10);
			count++;
		}	
	}
	
	public void refreshImage()
	{
		for (int i = 0; i < height; i++)
		{
			for (int j = 0; j < width; j++)
			{
				if ((i == 0 || i == height - 1) || (j == 0 || j == width - 1))
					System.out.print("");
				else
					arr[i][j] = ' ';
			}
		}
		for (int i = 0; i < shapes.size(); i++)
			shapes.get(i).draw(this);
	}
	
}
