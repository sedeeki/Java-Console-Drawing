package myPackage;

import java.util.ArrayList;

public class Circle extends Shape
{
	private int radius;
	private ArrayList <Line> lines;
	
	Circle()
	{
		radius = 0;
	}
	
	Circle(int x, int y, int r, char s)
	{
		this.basePointX = x;
		this.basePointY = y;
		this.radius = r;
		this.symbol = s;
		lines = new ArrayList <Line> ();
	}

	@Override
	public void draw(Window window) 
	{
		int xRight = this.basePointX - (radius/2) - 1;
		int yRight = this.basePointY - radius + 1;
		lines.add(new Line(xRight,yRight,radius,0,1,this.symbol));
		yRight = yRight + radius;
		lines.add(new Line(xRight,yRight,radius-1,1,1,this.symbol));
		xRight = xRight + radius - 1;
		yRight = yRight + radius - 1;
		lines.add(new Line(xRight,yRight,radius,1,0,this.symbol));
		xRight = xRight + radius;
		lines.add(new Line(xRight,yRight,radius-1,1,-1,this.symbol));
		
		int xLeft = this.basePointX - (radius/2) - 1;
		int yLeft = this.basePointY - radius + 1;
		lines.add(new Line(xLeft,yLeft,radius-1,1,-1,this.symbol));
		xLeft = xLeft + radius - 1;
		yLeft = yLeft - radius + 1;
		lines.add(new Line(xLeft,yLeft,radius,1,0,this.symbol));
		xLeft = xLeft + radius;
		lines.add(new Line(xLeft,yLeft,radius-1,1,1,this.symbol));
		xLeft = xLeft + radius - 1;
		yLeft = yLeft + radius - 1;
		lines.add(new Line(xLeft,yLeft,radius,0,1,this.symbol));
		
		
		for (int i = 0; i < lines.size(); i++)
			lines.get(i).draw(window);
	
	}
	
	public String toString()
	{
		String info;
		info = "circle\n";
		info = info + Integer.toString(this.basePointX) + " " + Integer.toString(this.basePointY) + " " 
				+ Integer.toString(this.radius) + "\n" + this.symbol;
		return info;
	}

	@Override
	public void displayInfo() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void increaseSize() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void decreaseSize() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void move(String s) {
		// TODO Auto-generated method stub
		
	}
}
