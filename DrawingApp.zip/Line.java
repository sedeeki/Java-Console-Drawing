package myPackage;

public class Line extends Shape
{
	
	private int length;
	private int incRow;
	private int incCol;
	
	Line()
	{
		this.symbol = '0';
		this.basePointX = 0;
		this.basePointY = 0;
		this.length = 0;
		this.incCol = 0;
		this.incRow = 0;
	}
	
	Line(int row, int col, int l, int incR, int incC, char s)
	{
		this.symbol = s;
		this.basePointX = row;
		this.basePointY = col;
		this.length = l;
		this.incCol = incC;
		this.incRow = incR;
	}
	
	@Override
	public void draw(Window window)
	{
		int x = this.basePointX;
		int y = this.basePointY;
		for (int i = 0; i < length + 1; i++)
		{
			window.getArr()[x][y] = symbol;
			x = x + this.incRow;
			y = y + this.incCol;
		}
	}
	
	public void increaseSize()
	{
		this.length++;
	}
	
	public void decreaseSize()
	{
		this.length++;
	}
	
	public void move(String s)
	{
		if (s.equals("l"))
			this.basePointY--;
		else if (s.equals("r"))
			this.basePointY++;
		else if (s.equals("d"))
			this.basePointX++;
		else if (s.equals("u"))
			this.basePointX--;
	}
	
	public void displayInfo()
	{
		System.out.println("line(" + this.basePointX + "," + this.basePointY 
				+ ")(" + this.length + ")(" + this.incRow + "," + this.incCol + ")(" + this.symbol + ")");
	}
	
	public String toString()
	{
		String info = "";
		info = info + "line\n";
		info = info + Integer.toString(this.basePointX) + " " + Integer.toString(this.basePointY) + " " 
				+ Integer.toString(this.length) + " " + Integer.toString(this.incRow) + " " 
				+ Integer.toString(this.incCol) + "\n" + this.symbol;
		return info;
	}
	
}
