package myPackage;

public class Text extends Shape
{
	private String text;
	private int incRow;
	private int incCol;
	
	Text()
	{
		text = " ";
		incRow = 0;
		incCol = 0;
	}
	
	Text(int x, int y, String s, int r, int c)
	{
		this.basePointX = x;
		this.basePointY = y;
		this.text = s;
		this.incCol = c;
		this.incRow = r;
	}

	
	public void draw(Window window) 
	{
		int x = this.basePointX;
		int y = this.basePointY;
		for (int i = 0; i < text.length(); i++)
		{
			window.getArr()[x][y] = text.charAt(i);
			x = x + this.incRow;
			y = y + this.incCol;
		}
		
	}

	public void increaseSize()
	{
		this.incRow++;
		this.incCol++;
	}
	
	public void decreaseSize()
	{
		this.incRow--;
		this.incCol--;
	}
	
	public void move(String s)
	{
		if (s.equals("l"))
			this.basePointY--;
		else if (s.equals("r"))
			this.basePointY++;
		else if (s.equals("d"))
			this.basePointX++;
		else if (s.equals("u"))
			this.basePointX--;
	}
	
	public void displayInfo()
	{
		System.out.println("line(" + this.basePointX + "," + this.basePointY 
				+ ")(" + this.incRow + "," + this.incCol + ")(" + this.text + ")");
	}
	
	public String toString()
	{
		String info = "";
		info = info + "text\n";
		info = info + Integer.toString(this.basePointX) + " " + Integer.toString(this.basePointY) + "\n" 
				+ this.text + "\n" + Integer.toString(this.incRow) + " " + Integer.toString(this.incCol);
		return info;
	}
}
