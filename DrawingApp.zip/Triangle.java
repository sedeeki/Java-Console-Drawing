package myPackage;

import java.util.ArrayList;

public class Triangle extends Shape
{
	private int height;
	private int incRow;
	private int incCol;
	private ArrayList <Line> lines;
	
	Triangle()
	{
		height = 0;
		incRow = 0;
		incCol = 0;
	}
	
	Triangle(int x, int y, int h, int r, int c, char s)
	{
		this.basePointX = x;
		this.basePointY = y;
		this.symbol = s;
		this.height = h;
		this.incCol = c;
		this.incRow = r;
		lines = new ArrayList <Line> ();
	}

	@Override
	public void draw(Window window) {
		
		if (this.incRow == 0 && this.incCol == 1)
		{
			lines.add(new Line(this.basePointX,this.basePointY,this.height-1 ,1,1,this.symbol));
			lines.add(new Line(this.basePointX,this.basePointY,this.height-1 ,-1,1,this.symbol));
			lines.add(new Line(this.basePointX - this.height, this.basePointY + this.height, this.height*2 , 1, 0, this.symbol));
		}
		
		else if (this.incRow == 0 && this.incCol == -1)
		{
			lines.add(new Line(this.basePointX,this.basePointY,this.height -1,1,-1,this.symbol));
			lines.add(new Line(this.basePointX,this.basePointY,this.height -1,-1,-1,this.symbol));
			lines.add(new Line(this.basePointX - this.height, this.basePointY - this.height, this.height*2 , 1, 0, this.symbol));
		}
		
		else if (this.incRow == 1 && this.incCol == 0)
		{
			lines.add(new Line(this.basePointX,this.basePointY,this.height-1 ,1,-1,this.symbol));
			lines.add(new Line(this.basePointX,this.basePointY,this.height-1,1,1,this.symbol));
			lines.add(new Line(this.basePointX + this.height, this.basePointY - this.height , this.height*2, 0, 1, this.symbol));
		}
		
		else if (this.incRow == -1 && this.incCol == 0)
		{
			lines.add(new Line(this.basePointX,this.basePointY,this.height -1,-1,-1,this.symbol));
			lines.add(new Line(this.basePointX,this.basePointY,this.height -1,-1,1,this.symbol));
			lines.add(new Line(this.basePointX- this.height , this.basePointY - this.height , this.height*2 , 0, 1, this.symbol));
		}
		
		for (int i = 0; i < lines.size(); i++)
			lines.get(i).draw(window);
	}

	public String toString()
	{
		String info;
		info = "triangle\n";
		info = info + Integer.toString(this.basePointX) + " " + Integer.toString(this.basePointY) + " " 
				+ Integer.toString(this.height) + " " + Integer.toString(this.incRow) + " "
				+ Integer.toString(this.incCol) + "\n" + this.symbol;
		return info;
	}
	
	@Override
	public void displayInfo() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void increaseSize() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void decreaseSize() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void move(String s) {
		// TODO Auto-generated method stub
		
	}

}
