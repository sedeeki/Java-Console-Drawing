package myPackage;

public abstract class Shape 
{
	public int basePointX;
	public int basePointY;
	public char symbol;
	
	public abstract void draw(Window window);
	public abstract void displayInfo();
	public abstract void increaseSize();
	public abstract void decreaseSize();
	public abstract void move(String s);
	
}
