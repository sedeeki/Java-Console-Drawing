package myPackage;

import java.util.Scanner;

public class T3Main 
{
	public static void main(String arg[]) throws Exception
	{
		String input;
		Window window = new Window();
		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter the name of file!: ");
		input = scanner.nextLine();
		try {
		window = Window.readSpecFromFile(input);
		window.display();
		}
		catch(Exception e)
		{
			System.out.println("File does not exist");
		}
		scanner.close();
		
	}
}
