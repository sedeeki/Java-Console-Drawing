package myPackage;

public class Rectangle extends Shape
{

	private int height;
	private int width;
	
	Rectangle()
	{
		height = 0;
		width = 0;
	}
	
	Rectangle(int x, int y, int h, int w, char s)
	{
		this.basePointX = x;
		this.basePointY = y;
		this.symbol = s;
		this.height = h;
		this.width = w;
	}
	
	@Override
	public void draw(Window window) {
		
		for (int i = this.basePointX; i < this.height + this.basePointX + 1; i++)
		{
			for (int j = this.basePointY; j < this.width + this.basePointY + 1; j++)
			{
				if ((i == this.basePointX || i == this.basePointX + height ) || 
						(j == this.basePointY || j == this.basePointY + width ))
					window.getArr()[i][j] = symbol;
				else
					window.getArr()[i][j] = ' ';
			}
		}
		
	}
	
	public void increaseSize()
	{
		this.height++;
		this.width++;
	}
	
	public void decreaseSize()
	{
		this.height--;
		this.width--;
	}
	
	public void move(String s)
	{
		if (s.equals("l"))
			this.basePointY--;
		else if (s.equals("r"))
			this.basePointY++;
		else if (s.equals("d"))
			this.basePointX++;
		else if (s.equals("u"))
			this.basePointX--;
	}
	
	public void displayInfo()
	{
		System.out.println("rectangle(" + this.basePointX + "," + this.basePointY 
				+ ")(" + this.height + "," + this.width + ")(" + this.symbol + ")");
	}
	
	
	public String toString()
	{
		String info;
		info = "rectangle\n";
		info = info + Integer.toString(this.basePointX) + " " + Integer.toString(this.basePointY) + " " 
				+ Integer.toString(this.height) + " " + Integer.toString(this.width) + "\n" + this.symbol;
		return info;
	}
	
}
